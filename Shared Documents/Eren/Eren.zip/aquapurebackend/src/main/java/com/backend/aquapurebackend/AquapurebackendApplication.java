package com.backend.aquapurebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AquapurebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AquapurebackendApplication.class, args);
	}

}
