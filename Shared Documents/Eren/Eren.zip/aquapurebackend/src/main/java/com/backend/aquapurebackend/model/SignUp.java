package com.backend.aquapurebackend.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class SignUp {

    @Id
    @GeneratedValue
    private Long User_ID;
    private String FirstName;
    private String LastName;
    private String eMail;
    private Integer PhoneNumber;
    private String DoB;
    private String Password;
    private String AddressLine1;
    private String AddressLine2;
    private String AddressTC;
    private String AddressPostcode;

    public Long getUser_ID() {
        return User_ID;
    }

    public void setUser_ID(Long user_ID) {
        User_ID = user_ID;
    }


    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }


    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }


    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }


    public Integer getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(Integer phoneNumber) {
        PhoneNumber = phoneNumber;
    }


    public String getDoB() {
        return DoB;
    }

    public void setDoB(String doB) {
        DoB = doB;
    }


    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }


    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        AddressLine1 = addressLine1;
    }


    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        AddressLine2 = addressLine2;
    }


    public String getAddressTC() {
        return AddressTC;
    }

    public void setAddressTC(String addressTC) {
        AddressTC = addressTC;
    }


    public String getAddressPostcode() {
        return AddressPostcode;
    }

    public void setAddressPostcode(String addressPostcode) {
        AddressPostcode = addressPostcode;
    }

}
