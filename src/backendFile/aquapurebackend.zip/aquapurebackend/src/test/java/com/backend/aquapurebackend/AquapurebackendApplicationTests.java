package com.backend.aquapurebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AquapurebackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
